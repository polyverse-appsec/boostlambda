from ..base import ShopifyResource


class ScriptTag(ShopifyResource):
    pass
