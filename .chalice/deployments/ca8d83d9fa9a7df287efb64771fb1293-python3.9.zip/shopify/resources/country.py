from ..base import ShopifyResource


class Country(ShopifyResource):
    pass
