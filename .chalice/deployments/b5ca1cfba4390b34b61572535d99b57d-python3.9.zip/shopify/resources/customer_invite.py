from ..base import ShopifyResource


class CustomerInvite(ShopifyResource):
    pass
